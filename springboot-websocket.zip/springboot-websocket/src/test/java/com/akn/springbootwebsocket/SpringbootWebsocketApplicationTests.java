package com.akn.springbootwebsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
