package com.akn.springbootwebsocket.repository;

import com.akn.springbootwebsocket.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
}
