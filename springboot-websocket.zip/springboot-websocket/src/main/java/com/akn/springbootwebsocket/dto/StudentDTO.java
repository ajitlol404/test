package com.akn.springbootwebsocket.dto;

import jakarta.validation.constraints.*;

public class StudentDTO {

    public record StudentRequestDTO(
            @NotBlank(message = "Name cannot be blank")
            @Size(min = 3, max = 255, message = "Name must be between 3 and 255 characters")
            String name,

            @NotBlank(message = "Email cannot be blank")
            @Email(message = "Email must be valid")
            @Size(max = 255, message = "Email must not exceed 255 characters")
            String email,

            @NotBlank(message = "Phone number cannot be blank")
            @Size(max = 255, message = "Phone number must not exceed 255 characters")
            String phoneNumber,

            @NotNull(message = "Age is required")
            @Positive(message = "Age must be a positive number")
            Integer age
    ) {
    }
}