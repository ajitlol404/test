package com.akn.springbootwebsocket.service;

import com.akn.springbootwebsocket.dto.StudentDTO.StudentRequestDTO;
import com.akn.springbootwebsocket.entity.Student;

import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();

    Student addStudent(StudentRequestDTO studentRequestDTO);
}
