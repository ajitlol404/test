package com.akn.springbootwebsocket.service.impl;

import com.akn.springbootwebsocket.dto.StudentDTO;
import com.akn.springbootwebsocket.entity.Student;
import com.akn.springbootwebsocket.repository.StudentRepository;
import com.akn.springbootwebsocket.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final SimpMessagingTemplate simpMessagingTemplate;

    @Override
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Student addStudent(StudentDTO.StudentRequestDTO studentRequestDTO) {
        Student student = new Student();
        student.setName(studentRequestDTO.name());
        student.setEmail(studentRequestDTO.email());
        student.setPhoneNumber(studentRequestDTO.phoneNumber());
        student.setAge(studentRequestDTO.age());
        return studentRepository.save(student);
//        messagingTemplate.convertAndSend("/topic/students", savedStudent); // Broadcast new student
    }
}

//
//@Configuration
//@EnableWebSocketMessageBroker
//public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
//
//    @Override
//    public void registerStompEndpoints(StompEndpointRegistry registry) {
//        registry.addEndpoint("/ws").withSockJS(); // WebSocket endpoint with SockJS fallback
//    }
//
//    @Override
//    public void configureMessageBroker(MessageBrokerRegistry config) {
//        config.enableSimpleBroker("/topic");  // For broadcasting messages
//        config.setApplicationDestinationPrefixes("/app"); // For sending messages from client
//    }
//}











//
//<!DOCTYPE html>
//<html xmlns:th="http://www.thymeleaf.org">
//<head>
//<title>Student List</title>
//    <script src="https://cdn.jsdelivr.net/npm/sockjs-client@1/dist/sockjs.min.js"></script>
//    <script src="https://cdn.jsdelivr.net/npm/stompjs@2.3.3/lib/stomp.min.js"></script>
//</head>
//<body>
//<h2>Student List</h2>
//
//<form id="studentForm">
//    <input type="text" id="name" placeholder="Name" required>
//    <input type="number" id="age" placeholder="Age" required>
//    <button type="submit">Add Student</button>
//</form>
//
//<ul id="studentList"></ul>
//
//<script>
//        let stompClient = null;
//
//function connect() {
//        const socket = new SockJS('/ws');
//    stompClient = Stomp.over(socket);
//    stompClient.connect({}, function () {
//        stompClient.subscribe('/topic/students', function (message) {
//                const newStudent = JSON.parse(message.body);
//                const list = document.getElementById('studentList');
//                const item = document.createElement('li');
//            item.textContent = newStudent.name + " - " + newStudent.age + " years old";
//            list.appendChild(item);
//        });
//
//        loadStudents(); // Load students initially
//    });
//}
//
//function loadStudents() {
//    fetch('/student')
//            .then(response => response.json())
//            .then(students => {
//                const list = document.getElementById('studentList');
//    list.innerHTML = '';
//    students.forEach(student => {
//                    const item = document.createElement('li');
//    item.textContent = student.name + " - " + student.age + " years old";
//    list.appendChild(item);
//                });
//            });
//}
//
//    document.getElementById('studentForm').addEventListener('submit', function (event) {
//    event.preventDefault();
//        const name = document.getElementById('name').value;
//        const age = document.getElementById('age').value;
//
//    fetch('/student', {
//            method: 'POST',
//            headers: {'Content-Type': 'application/json'},
//    body: JSON.stringify({name: name, age: age})
//        }).then(response => response.json())
//            .then(data => {
//                    document.getElementById('name').value = '';
//    document.getElementById('age').value = '';
//          });
//});
//
//connect();  // Initialize WebSocket connection
//</script>
//</body>
//</html>